<?php

session_start();
   include("dbconnect.php");

$error="";
   if(isset($_POST['login'])){
   
      // username and password sent from form 
      
      $email = $_POST['email'];
      $password = $_POST['password']; 
      
      $sql = "SELECT id,email FROM details WHERE email = '$email' and password = '$password'";
          $result= $connect->query($sql);

      $row = $result->fetch_array();
      $user_id = $row[0]; 
      $email_id = $row[1]; 
  
      
      echo $count = mysqli_num_rows($result);


      if($count >0) {
     $_SESSION['userid'] = $user_id;
    $_SESSION['email'] = $email_id;

 
        echo "LOGIN SUCCESS ";
         header("location: ../welcome.php");
      }
      else {
        echo $error = "Your Login Name or Password is invalid";
      }
   }
?>