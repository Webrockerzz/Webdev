<?php

include "dbconnect.php";

 $name = $_POST['name'];
 $password = $_POST['password'];
 $email_id = $_POST['email'];
date_default_timezone_set('Asia/Kolkata');


echo $image_name = date("Y-m-d-h-i-sa").$_FILES['image']['name'];  
        
//      	$image_name =  $_FILES['image']['name'];
	$image_type = $_FILES['image']['type'];
	$image_size = $_FILES['image']['size'];
	$image_tmp_name= $_FILES['image']['tmp_name'];
//	$desc = $_POST['desc'];

//       echo $image_type;
//            
 echo    $sql="INSERT INTO `details`(`name`, `email`, `password`,`img`)
     VALUES('$name','$email_id','$password','$image_name')";

     
   $result= $connect->query($sql);

   if ($result)
    {
        echo "Success";
    }
    else{
        echo "failed";
   }
    
move_uploaded_file($image_tmp_name,"../images/$image_name");



$countfiles = count($_FILES['image1']['name']);
    
    for($i = 0;$i < $countfiles; $i++){
        
        
        $img = $_FILES['image1']['name'][$i];
       echo $sql1="INSERT INTO `images`(`img-name`)VALUES('$img')";
           $result1= $connect->query($sql1);
//        $maxFileSize = 5 * 1024 * 1024;
      
    if(move_uploaded_file($_FILES['image1']['tmp_name'][$i],'../images/' .$img)){
        echo "File ".$img." uploaded<br>";
    }
        else{
            echo "Error Uploading Files";
        }
   
}
        

    
//    print_r($sports); to print array
    
     

 //header("Location: ../phpform.php");
    
    


?>