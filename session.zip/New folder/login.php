<?php
session_start();
if(isset($_SESSION['userid']))
{
       header("location: welcome.php");
}

?>


<!DOCTYPE html>
<html>
<head>
     <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
   
    <body>
        
        
        
<!--
        
        <form method="post" action="php_action/loginfun.php">
         <label>Email-Id:</label><input  type="email" name="email" placeholder="Enter Your mail-id"><br><br>
        <label>Password:</label><input  type="password" name="password" placeholder="Enter Your Password"><br><br>
       
        <input type="submit" name="login" value="Submit"><br><br>
        
     
        </form>
-->
        
       <div class="login-page" >
  <div class="form">
<!--
    <form class="register-form" method="post" action="php_action/login_action.php">
      <input type="text" placeholder="name"/>
      <input type="password" name="password" placeholder="password"/>
      <input type="email" name="email" placeholder="email address"/>
       <input type="button" name="submit" value="Submit" placeholder="email address"/>
      <p class="message">Already registered? <a href="#">Sign In</a></p>
    </form>
-->
    <form class="login-form" method="post" action="php_action/login_action.php">
      <input type="email" name="email" placeholder="email"/>
      <input type="password" name="password" placeholder="password"/>
        
            
            <input type="submit" name="login" placeholder="Login" value="Login" style=" text-transform: uppercase;
  outline: 0;
  background: #4CAF50;
  width: 100%;
  border: 0;
  padding: 15px;
  color: white;
  font-size: 14px;
  -webkit-transition: all 0.3 ease;
  transition: all 0.3 ease;
  cursor: pointer;">

      <p class="message">Not registered? <a href="registeer.php">Create an account</a></p>
    </form>
  </div>
</div>
        
        
    
    </body>
</html>

