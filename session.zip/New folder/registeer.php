<!DOCTYPE html>
<html>
<head>
     <link href="style.css" type="text/css" rel="stylesheet" />
    </head>
   
    <body>
        
        
        
<!--
        
        <form method="post" action="php_action/loginfun.php">
         <label>Email-Id:</label><input  type="email" name="email" placeholder="Enter Your mail-id"><br><br>
        <label>Password:</label><input  type="password" name="password" placeholder="Enter Your Password"><br><br>
       
        <input type="submit" name="login" value="Submit"><br><br>
        
     
        </form>
-->
        
       <div class="login-page" >
  <div class="form">
    <form class="register-form" method="post" action="php_action/register_action.php" enctype="multipart/form-data" style="display:block;">
      <input type="text" name="name" placeholder="name"/>
      <input type="password" name="password" placeholder="password"/>
      <input type="email" name="email" placeholder="email address"/>
        <input type="file" name="image">
        <label>Use this for multiple images</label><input type="file" name="image1[]" multiple>
        
      <input class="submit"type="submit" name="Create" value="Create">
      <p class="message">Already registered? <a href="login.php">Sign In</a></p>
    </form>
<!--
    <form class="login-form" style="display:none;">
      <input type="email" name="email " placeholder="username"/>
      <input type="password" name="password" placeholder="password"/>
      <button>login</button>
      <p class="message">Not registered? <a href="register.php">Create an account</a></p>
    </form>
-->
  </div>
</div>
        
        
    
    </body>
</html>

