<?php
session_start();

if(!isset($_SESSION['userid']))
{
       header("location: login.php");
}
echo $_SESSION['userid']."<br>";
echo $_SESSION['email']."<br>";

?>

<a href="php_action/logout.php">Logout</a>